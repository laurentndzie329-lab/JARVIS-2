package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var statusText: TextView
    private lateinit var conversationText: TextView
    private lateinit var commandInput: EditText
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsReady = false

    companion object {
        private const val AUDIO_PERMISSION_REQUEST = 200
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildInterface()
        addMessage("JARVIS", "Bonjour ! Je suis JARVIS 2.0. Appuie sur le micro ou écris une commande.")
        setupSpeechRecognizer()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "JARVIS 2.0"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFF64D8CB.toInt())
        }
        root.addView(title, matchWidthWrap())

        statusText = TextView(this).apply {
            text = "Assistant prêt"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C7CC.toInt())
            setPadding(0, 12, 0, 16)
        }
        root.addView(statusText, matchWidthWrap())

        conversationText = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            addView(conversationText)
            setBackgroundColor(0xFF1B2833.toInt())
        }
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        commandInput = EditText(this).apply {
            hint = "Écris une commande..."
            setHintTextColor(0xFF9AAAB2.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(true)
        }
        root.addView(commandInput, matchWidthWrap())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val sendButton = Button(this).apply {
            text = "Envoyer"
            setOnClickListener {
                val command = commandInput.text.toString().trim()
                if (command.isNotEmpty()) {
                    addMessage("Toi", command)
                    commandInput.setText("")
                    handleCommand(command)
                }
            }
        }
        val micButton = Button(this).apply {
            text = "🎙 Parler"
            setOnClickListener { startVoiceRecognition() }
        }
        buttons.addView(sendButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(micButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(buttons, matchWidthWrap())

        setContentView(root)
    }

    private fun matchWidthWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun addMessage(speaker: String, message: String) {
        conversationText.append("$speaker : $message\n\n")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.FRANCE)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            if (ttsReady) statusText.text = "Voix française prête"
        } else {
            statusText.text = "Synthèse vocale indisponible"
        }
    }

    private fun setupSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "Reconnaissance vocale indisponible sur cet appareil"
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "Je t'écoute..."
            }
            override fun onBeginningOfSpeech() {
                statusText.text = "Parle maintenant"
            }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                statusText.text = "Traitement..."
            }
            override fun onError(error: Int) {
                statusText.text = "Je n'ai pas compris. Réessaie."
            }
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = matches?.firstOrNull().orEmpty()
                if (command.isNotBlank()) {
                    addMessage("Toi", command)
                    handleCommand(command)
                } else {
                    statusText.text = "Aucune commande reconnue"
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startVoiceRecognition() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            return
        }
        if (speechRecognizer == null) setupSpeechRecognizer()
        val recognizer = speechRecognizer ?: run {
            reply("La reconnaissance vocale n'est pas disponible.")
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parle à JARVIS")
        }
        try {
            recognizer.startListening(intent)
        } catch (_: Exception) {
            reply("Je ne peux pas démarrer l'écoute pour le moment.")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startVoiceRecognition()
            } else {
                reply("Tu dois autoriser le microphone pour utiliser la commande vocale.")
            }
        }
    }

    private fun handleCommand(rawCommand: String) {
        val command = rawCommand.lowercase(Locale.FRANCE)
            .replace("’", "'")
            .trim()

        when {
            command.contains("ouvre whatsapp") || command == "whatsapp" ->
                openApp("com.whatsapp", "WhatsApp")
            command.contains("ouvre youtube") || command == "youtube" ->
                openApp("com.google.android.youtube", "YouTube")
            command.contains("ouvre chrome") || command == "chrome" ->
                openApp("com.android.chrome", "Chrome")
            command.contains("ouvre facebook") || command == "facebook" ->
                openApp("com.facebook.katana", "Facebook")
            command.contains("ouvre instagram") || command == "instagram" ->
                openApp("com.instagram.android", "Instagram")
            command.contains("ouvre les paramètres") || command.contains("ouvre paramètres") ->
                openSettings()
            command.contains("quelle heure") || command.contains("l'heure") ->
                reply("Il est " + SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date()))
            command.contains("quelle date") || command.contains("quel jour") ->
                reply("Nous sommes le " + SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date()))
            command.contains("bonjour") || command.contains("salut") ->
                reply("Bonjour ! Comment puis-je t'aider ?")
            command.contains("qui es-tu") || command.contains("ton nom") ->
                reply("Je suis JARVIS 2.0, ton assistant vocal Android.")
            command.contains("merci") ->
                reply("Avec plaisir.")
            else ->
                reply("Je suis en mode de base. Je peux répondre à quelques commandes et ouvrir certaines applications. L'intelligence artificielle connectée sera ajoutée dans une prochaine étape.")
        }
    }

    private fun openApp(packageName: String, appName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            reply("J'ouvre $appName.")
            try {
                startActivity(launchIntent)
            } catch (_: Exception) {
                reply("Je n'ai pas réussi à ouvrir $appName.")
            }
        } else {
            reply("$appName ne semble pas installé sur cet appareil.")
        }
    }

    private fun openSettings() {
        reply("J'ouvre les paramètres.")
        try {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
        } catch (_: Exception) {
            reply("Je ne peux pas ouvrir les paramètres.")
        }
    }

    private fun reply(message: String) {
        addMessage("JARVIS", message)
        if (ttsReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
        statusText.text = "Assistant prêt"
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
