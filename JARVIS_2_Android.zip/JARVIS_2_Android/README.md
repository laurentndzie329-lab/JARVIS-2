# JARVIS 2.0 — Android starter

Ce projet est une première base Android compilable depuis GitHub Actions.

## Fonctions incluses
- Interface simple en français
- Reconnaissance vocale déclenchée par le bouton « Parler »
- Réponse vocale en français avec la synthèse vocale Android
- Commandes locales simples : salutation, heure, date
- Ouverture de quelques applications installées : WhatsApp, YouTube, Chrome, Facebook et Instagram
- Ouverture des paramètres Android

## Limites de cette première version
- Le microphone n'écoute pas en permanence : l'utilisateur appuie sur le bouton pour parler.
- Le mot d'activation personnalisé et le service permanent ne sont pas inclus.
- Les réponses sont locales et limitées : aucune IA en ligne n'est encore connectée.
- L'ouverture d'une application dépend de sa présence sur le téléphone et des autorisations Android.

## Compilation
Le workflow GitHub Actions fourni dans le dépôt attend ce dossier à l'intérieur de `JARVIS_2_Android.zip`.
Il compile avec Java 17, Android SDK 35 et Gradle 8.9.
